/* Kode bersama aplikasi penumpang dan driver */
(function () {
  'use strict';
  var PC = window.PC = {};

  // ---------- Layanan dan tarif (ubah angka di sini) ----------
  PC.SERVICES = {
    passenger: [
      { id: 'bike',  name: 'Prima Bike',   icon: '🏍️', desc: 'Ojek motor · 1 penumpang',  vehicle: 'motor', base: 3000, perKm: 2500, min: 9000 },
      { id: 'car',   name: 'Prima Car',    icon: '🚗',       desc: 'Mobil · 4 penumpang',       vehicle: 'mobil', base: 6000, perKm: 4500, min: 18000 },
      { id: 'carxl', name: 'Prima Car XL', icon: '🚐',       desc: 'Mobil besar · 6 penumpang', vehicle: 'mobil', base: 8000, perKm: 5500, min: 25000 }
    ],
    courier: [
      { id: 'send_bike', name: 'Prima Send Motor', icon: '📦', desc: 'Kurir motor · barang kecil (maks. 20 kg)',  vehicle: 'motor', base: 5000,  perKm: 2800, min: 10000 },
      { id: 'send_car',  name: 'Prima Send Mobil', icon: '🚚', desc: 'Kurir mobil · barang besar (maks. 200 kg)', vehicle: 'mobil', base: 15000, perKm: 5000, min: 30000 }
    ]
  };

  var OSRM = 'https://router.project-osrm.org/route/v1/driving/';
  var NOMINATIM = 'https://nominatim.openstreetmap.org/';

  // ---------- Util ----------
  PC.$ = function (id) { return document.getElementById(id); };

  PC.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };

  PC.rupiah = function (n) {
    return 'Rp' + Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  };

  PC.fare = function (svc, km) {
    var raw = svc.base + svc.perKm * km;
    return Math.max(svc.min, Math.ceil(raw / 500) * 500);
  };

  PC.fmtKm = function (meters) { return (meters / 1000).toFixed(1).replace('.', ',') + ' km'; };

  PC.fmtMin = function (seconds) {
    var m = Math.max(1, Math.round(seconds / 60));
    if (m < 60) { return m + ' mnt'; }
    return Math.floor(m / 60) + ' j ' + (m % 60) + ' mnt';
  };

  PC.haversine = function (a, b) {
    var R = 6371000, rad = Math.PI / 180;
    var dLat = (b.lat - a.lat) * rad, dLng = (b.lng - a.lng) * rad;
    var x = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(a.lat * rad) * Math.cos(b.lat * rad) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
    return 2 * R * Math.asin(Math.sqrt(x));
  };

  PC.firstName = function (n) { return String(n || '').trim().split(/\s+/)[0] || 'Pelanggan'; };

  PC.normPhone = function (p) {
    var d = String(p || '').replace(/\D/g, '');
    if (d.indexOf('62') === 0) { return d; }
    if (d.indexOf('0') === 0) { return '62' + d.slice(1); }
    return '62' + d;
  };

  PC.validPhone = function (p) {
    var n = PC.normPhone(p);
    return /^628\d{7,11}$/.test(n);
  };

  var toastTimer = null;
  PC.toast = function (msg) {
    var t = PC.$('toast');
    t.textContent = msg;
    t.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.add('hidden'); }, 4000);
  };

  PC.alertUser = function () {
    try { if (navigator.vibrate) { navigator.vibrate([200, 100, 200]); } } catch (e) { /* abaikan */ }
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) { return; }
      if (!PC._ac) { PC._ac = new AC(); }
      var o = PC._ac.createOscillator(), g = PC._ac.createGain();
      o.connect(g); g.connect(PC._ac.destination);
      o.frequency.value = 880; g.gain.value = 0.2;
      o.start(); o.stop(PC._ac.currentTime + 0.25);
    } catch (e) { /* abaikan */ }
  };

  PC.getJSON = function (url, ms) {
    var ctrl = ('AbortController' in window) ? new AbortController() : null;
    var timer = ctrl ? setTimeout(function () { ctrl.abort(); }, ms || 12000) : null;
    return fetch(url, ctrl ? { signal: ctrl.signal } : {}).then(function (r) {
      if (timer) { clearTimeout(timer); }
      if (!r.ok) { throw new Error('HTTP ' + r.status); }
      return r.json();
    }).catch(function (e) {
      if (timer) { clearTimeout(timer); }
      throw e;
    });
  };

  PC.errText = function (e) {
    var c = e && e.code ? String(e.code) : '';
    if (c === 'permission-denied') { return 'Ditolak server (aturan Firestore belum dipasang atau akun belum disetujui).'; }
    if (c === 'unavailable' || c === 'auth/network-request-failed') { return 'Tidak ada koneksi internet.'; }
    return (e && e.message) ? e.message : 'Terjadi kesalahan.';
  };

  // ---------- Overlay (dialog bawah) ----------
  var actHandler = null;
  var okCb = null;

  PC.onAct = function (fn) { actHandler = fn; };
  PC.kv = function (k, v) { return '<div class="kv"><span>' + PC.esc(k) + '</span><span>' + v + '</span></div>'; };

  PC.openOverlay = function (html) {
    PC.$('overlayBody').innerHTML = html;
    PC.$('overlay').classList.remove('hidden');
  };
  PC.closeOverlay = function () {
    PC.$('overlay').classList.add('hidden');
    PC.$('overlayBody').innerHTML = '';
  };
  PC.confirmBox = function (title, text, okText, onOk) {
    okCb = onOk;
    PC.openOverlay('<h2>' + PC.esc(title) + '</h2><p class="note">' + PC.esc(text) + '</p>' +
      '<div class="btnrow"><button class="btn ghost" data-act="_no" type="button">Kembali</button>' +
      '<button class="btn primary" data-act="_ok" type="button">' + PC.esc(okText) + '</button></div>');
  };

  document.addEventListener('DOMContentLoaded', function () {
    PC.$('overlayBody').addEventListener('click', function (ev) {
      var t = ev.target.closest('[data-act]');
      if (!t) { return; }
      var act = t.getAttribute('data-act');
      if (act === '_no') { PC.closeOverlay(); okCb = null; return; }
      if (act === '_ok') { var cb = okCb; okCb = null; PC.closeOverlay(); if (cb) { cb(); } return; }
      if (actHandler) { actHandler(act, t); }
    });
  });

  // ---------- Peta / lokasi ----------
  PC.pinIcon = function (kind) {
    return L.divIcon({ className: '', html: '<div class="pin pin-' + kind + '"></div>', iconSize: [28, 36], iconAnchor: [14, 34] });
  };
  PC.emojiIcon = function (e) {
    return L.divIcon({ className: '', html: '<div class="emo">' + e + '</div>', iconSize: [34, 34], iconAnchor: [17, 17] });
  };

  PC.makeMap = function (center) {
    var map = L.map('map', { zoomControl: false }).setView(center, 12);
    map.attributionControl.setPrefix(false);
    L.control.zoom({ position: 'topright' }).addTo(map);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);
    return map;
  };

  PC.locateOnce = function () {
    return new Promise(function (resolve, reject) {
      if (!navigator.geolocation) { reject(new Error('nogps')); return; }
      navigator.geolocation.getCurrentPosition(function (pos) {
        resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude });
      }, function (e) { reject(e); }, { enableHighAccuracy: true, timeout: 12000, maximumAge: 30000 });
    });
  };

  PC.reverse = function (lat, lng) {
    var url = NOMINATIM + 'reverse?format=jsonv2&zoom=18&accept-language=id&lat=' + lat + '&lon=' + lng;
    return PC.getJSON(url, 10000).then(function (res) {
      if (!res || !res.display_name) { throw new Error('none'); }
      return res.display_name.split(', ').slice(0, 3).join(', ');
    }).catch(function () {
      return 'Titik di peta (' + lat.toFixed(4) + ', ' + lng.toFixed(4) + ')';
    });
  };

  PC.search = function (q, center) {
    var d = 0.6;
    var viewbox = [center.lng - d, center.lat + d, center.lng + d, center.lat - d].join(',');
    var url = NOMINATIM + 'search?format=jsonv2&limit=5&countrycodes=id&accept-language=id' +
      '&viewbox=' + viewbox + '&q=' + encodeURIComponent(q);
    return PC.getJSON(url, 10000).then(function (list) {
      return list.map(function (r) {
        var parts = r.display_name.split(', ');
        return { lat: parseFloat(r.lat), lng: parseFloat(r.lon), title: parts.slice(0, 2).join(', '),
                 sub: parts.slice(2, 5).join(', '), label: parts.slice(0, 3).join(', ') };
      });
    });
  };

  // Tidak pernah gagal: bila server rute tidak terjangkau, pakai perkiraan garis lurus.
  PC.route = function (a, b) {
    var url = OSRM + a.lng + ',' + a.lat + ';' + b.lng + ',' + b.lat + '?overview=full&geometries=geojson';
    return PC.getJSON(url, 15000).then(function (res) {
      if (!res.routes || !res.routes.length) { throw new Error('no route'); }
      var r = res.routes[0];
      return {
        distance: r.distance, duration: r.duration, approx: false,
        coords: r.geometry.coordinates.map(function (c) { return [c[1], c[0]]; })
      };
    }).catch(function () {
      var d = PC.haversine(a, b) * 1.3;
      return { distance: d, duration: d / 8.3, approx: true, coords: [[a.lat, a.lng], [b.lat, b.lng]] };
    });
  };

  // ---------- Login / daftar ----------
  var ERR = {
    'auth/email-already-in-use': 'Nomor HP ini sudah terdaftar. Silakan masuk.',
    'auth/wrong-password': 'Nomor HP atau kata sandi salah.',
    'auth/invalid-credential': 'Nomor HP atau kata sandi salah.',
    'auth/user-not-found': 'Nomor HP belum terdaftar.',
    'auth/invalid-login-credentials': 'Nomor HP atau kata sandi salah.',
    'auth/weak-password': 'Kata sandi minimal 6 karakter.',
    'auth/too-many-requests': 'Terlalu banyak percobaan. Coba lagi beberapa menit lagi.',
    'auth/network-request-failed': 'Tidak ada koneksi internet.',
    'auth/operation-not-allowed': 'Login Email/Password belum diaktifkan di Firebase (lihat PANDUAN_FIREBASE.md langkah 2).',
    'auth/api-key-not-valid.-please-pass-a-valid-api-key.': 'API key Firebase salah. Periksa firebase-config.js.',
    'auth/invalid-api-key': 'API key Firebase salah. Periksa firebase-config.js.'
  };

  function authError(e) {
    var c = e && e.code ? e.code : '';
    return ERR[c] || PC.errText(e);
  }

  function showFatal(title, text, withReload) {
    var box = PC.$('auth');
    box.classList.remove('hidden');
    box.innerHTML = '<div class="authbox"><div class="brand big">Prima<span>' + (PC.role === 'driver' ? 'Driver' : 'Carts') + '</span></div>' +
      '<h2>' + PC.esc(title) + '</h2><p class="note">' + PC.esc(text) + '</p>' +
      (withReload ? '<button class="btn primary" id="aReload" type="button">Coba lagi</button>' : '') + '</div>';
    if (withReload) { PC.$('aReload').addEventListener('click', function () { location.reload(); }); }
  }

  function showAuth(mode, info) {
    var isDriver = PC.role === 'driver';
    var reg = (mode === 'register' || mode === 'complete');
    info = info || PC.authNotice;
    PC.authNotice = null;
    var box = PC.$('auth');
    box.classList.remove('hidden');

    var h = '<div class="authbox"><div class="brand big">Prima<span>' + (isDriver ? 'Driver' : 'Carts') + '</span></div>';
    if (mode === 'complete') {
      h += '<h2>Lengkapi data akun</h2>';
    } else {
      h += '<div class="tabs"><button class="tab' + (mode === 'login' ? ' active' : '') + '" data-m="login" type="button">Masuk</button>' +
           '<button class="tab' + (mode === 'register' ? ' active' : '') + '" data-m="register" type="button">Daftar' + (isDriver ? ' driver' : '') + '</button></div>';
    }
    h += '<label for="aPhone">Nomor HP</label><input id="aPhone" type="tel" inputmode="tel" maxlength="16" placeholder="08xxxxxxxxxx" autocomplete="tel">';
    if (mode !== 'complete') {
      h += '<label for="aPass">Kata sandi</label><input id="aPass" type="password" maxlength="40" placeholder="Minimal 6 karakter" autocomplete="' + (reg ? 'new-password' : 'current-password') + '">';
    }
    if (reg) {
      h += '<label for="aName">Nama lengkap</label><input id="aName" type="text" maxlength="40" placeholder="Nama Anda">';
      if (isDriver) {
        h += '<label for="aVType">Jenis kendaraan</label><select id="aVType"><option value="motor">Motor</option><option value="mobil">Mobil</option></select>' +
             '<label for="aVName">Merek / tipe kendaraan</label><input id="aVName" type="text" maxlength="30" placeholder="Contoh: Honda Beat hitam">' +
             '<label for="aPlate">Plat nomor</label><input id="aPlate" type="text" maxlength="12" placeholder="B 1234 XYZ" autocapitalize="characters">';
      }
    }
    h += '<div id="aErr" class="aerr">' + PC.esc(info || '') + '</div>';
    h += '<button class="btn primary" id="aGo" type="button">' + (mode === 'login' ? 'Masuk' : (mode === 'complete' ? 'Simpan' : 'Daftar')) + '</button>';
    if (isDriver && reg) {
      h += '<p class="note">Setelah mendaftar, akun driver perlu disetujui admin sebelum bisa menerima order.</p>';
    }
    h += '</div>';
    box.innerHTML = h;

    if (mode === 'complete' && PC.user && PC.user.email) {
      PC.$('aPhone').value = '0' + PC.user.email.split('@')[0].replace(/^62/, '');
      PC.$('aPhone').readOnly = true;
    }

    Array.prototype.forEach.call(box.querySelectorAll('[data-m]'), function (b) {
      b.addEventListener('click', function () { showAuth(b.getAttribute('data-m')); });
    });

    function setErr(m) { PC.$('aErr').textContent = m || ''; }
    function busy(on) { PC.$('aGo').disabled = on; PC.$('aGo').textContent = on ? 'Mohon tunggu…' : (mode === 'login' ? 'Masuk' : (mode === 'complete' ? 'Simpan' : 'Daftar')); }

    PC.$('aGo').addEventListener('click', function () {
      setErr('');
      var phone = PC.$('aPhone').value.trim();
      if (!PC.validPhone(phone)) { setErr('Nomor HP belum benar (contoh 081234567890).'); return; }
      var np = PC.normPhone(phone);
      var email = np + '@primacarts.app';

      if (mode === 'login') {
        var pw = PC.$('aPass').value;
        if (pw.length < 6) { setErr('Kata sandi minimal 6 karakter.'); return; }
        busy(true);
        PC.auth.signInWithEmailAndPassword(email, pw).catch(function (e) { busy(false); setErr(authError(e)); });
        return;
      }

      var name = PC.$('aName').value.trim();
      if (name.length < 2) { setErr('Isi nama lengkap.'); return; }
      var prof = { role: PC.role, name: name, phone: np, approved: PC.role === 'passenger' };
      if (isDriver) {
        prof.vehicleType = PC.$('aVType').value;
        prof.vehicleName = PC.$('aVName').value.trim();
        prof.plate = PC.$('aPlate').value.trim().toUpperCase();
        prof.activeJobId = null;
        if (prof.vehicleName.length < 2 || prof.plate.length < 3) { setErr('Isi merek kendaraan dan plat nomor.'); return; }
      } else {
        prof.activeOrderId = null;
      }
      prof.createdAt = PC.FV.serverTimestamp();

      busy(true);
      if (mode === 'complete') {
        PC.db.collection('users').doc(PC.user.uid).set(prof).then(function () { proceed(prof); })
          .catch(function (e) { busy(false); setErr(authError(e)); });
        return;
      }
      var pw2 = PC.$('aPass').value;
      if (pw2.length < 6) { busy(false); setErr('Kata sandi minimal 6 karakter.'); return; }
      PC.registering = true;
      PC.auth.createUserWithEmailAndPassword(email, pw2).then(function (cred) {
        PC.user = cred.user;
        return PC.db.collection('users').doc(cred.user.uid).set(prof).then(function () {
          PC.registering = false;
          proceed(prof);
        });
      }).catch(function (e) {
        PC.registering = false;
        busy(false);
        if (PC.user && !(e && e.code && e.code.indexOf('auth/') === 0)) {
          showAuth('complete', 'Akun dibuat, tetapi data belum tersimpan: ' + authError(e));
        } else {
          setErr(authError(e));
        }
      });
    });
  }

  function proceed(profile) {
    if (profile.role !== PC.role) {
      var other = profile.role === 'driver' ? 'driver' : 'penumpang';
      PC.authNotice = 'Nomor ini terdaftar sebagai ' + other + '. Gunakan aplikasi ' + other + '.';
      PC.auth.signOut(); // onAuthStateChanged akan menampilkan layar login beserta pesannya
      return;
    }
    PC.profile = profile;
    PC.$('auth').classList.add('hidden');
    PC.$('auth').innerHTML = '';
    if (PC.readyUid !== PC.user.uid) {
      PC.readyUid = PC.user.uid;
      PC.onReady(PC.user, profile);
    }
  }

  PC.logout = function () {
    PC.auth.signOut().then(function () { location.reload(); });
  };

  PC.start = function (role, onReady) {
    PC.role = role;
    PC.onReady = onReady;
    var cfg = window.PC_FIREBASE_CONFIG;
    if (!cfg || !cfg.apiKey || String(cfg.apiKey).indexOf('ISI_') === 0) {
      showFatal('Server belum dihubungkan', 'Isi file firebase-config.js sesuai PANDUAN_FIREBASE.md, lalu build ulang aplikasi.', false);
      return;
    }
    if (typeof firebase === 'undefined') {
      showFatal('Tidak ada koneksi', 'Aplikasi butuh internet untuk memuat layanan. Periksa koneksi Anda.', true);
      return;
    }
    firebase.initializeApp(cfg);
    PC.auth = firebase.auth();
    PC.db = firebase.firestore();
    try { PC.db.settings({ experimentalAutoDetectLongPolling: true, merge: true }); } catch (e) { /* abaikan */ }
    PC.FV = firebase.firestore.FieldValue;

    PC.auth.onAuthStateChanged(function (user) {
      if (PC.registering) { return; }
      if (!user) { PC.user = null; PC.readyUid = null; showAuth('login'); return; }
      PC.user = user;
      PC.db.collection('users').doc(user.uid).get().then(function (snap) {
        if (!snap.exists) { showAuth('complete'); return; }
        proceed(snap.data());
      }).catch(function (e) {
        showFatal('Gagal memuat akun', PC.errText(e), true);
      });
    });
  };
})();
