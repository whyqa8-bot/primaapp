// ISI dengan konfigurasi Firebase Anda.
// Cara mendapatkannya ada di PANDUAN_FIREBASE.md (langkah 5).
// Ganti semua tulisan ISI_... dengan nilai dari Firebase Console.
window.PC_FIREBASE_CONFIG = {
  apiKey: "ISI_API_KEY",
  authDomain: "ISI_PROJECT_ID.firebaseapp.com",
  projectId: "ISI_PROJECT_ID",
  storageBucket: "ISI_PROJECT_ID.appspot.com",
  messagingSenderId: "ISI_SENDER_ID",
  appId: "ISI_APP_ID"
};
