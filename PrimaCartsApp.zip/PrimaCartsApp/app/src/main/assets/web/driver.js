(function () {
  'use strict';

  var $ = PC.$, esc = PC.esc, rupiah = PC.rupiah;
  var DEFAULT_CENTER = [-6.1754, 106.8272];
  var MAX_PICKUP_M = 15000;   // order ditampilkan bila jemputnya maksimal 15 km dari driver
  var LOC_PUSH_MS = 6000;     // kirim posisi ke penumpang tiap 6 detik saat ada order

  var map = null;
  var meMarker = null;
  var pos = null;
  var watchId = null;
  var lastLocPush = 0;
  var lastListRender = 0;

  var approved = false;
  var started = false;
  var online = false;

  var offers = {};            // id -> order (status searching)
  var offersFirst = true;
  var unsubOffers = null;
  var skipIds = {};           // order yang baru dilepas, jangan tampil lagi

  var unsubJob = null;
  var job = null;
  var contact = null;
  var jobLayers = [];
  var jobMapKey = '';
  var accepting = false;

  function tms(t) { return t && t.toMillis ? t.toMillis() : (t || 0); }

  // ---------- Lokasi ----------
  function startGeo() {
    if (watchId !== null || !navigator.geolocation) { return; }
    watchId = navigator.geolocation.watchPosition(onPos, function () {
      PC.toast('Lokasi tidak terbaca. Aktifkan GPS dan izin lokasi.');
    }, { enableHighAccuracy: true, maximumAge: 5000, timeout: 20000 });
  }

  function stopGeo() {
    if (watchId !== null && navigator.geolocation) { navigator.geolocation.clearWatch(watchId); }
    watchId = null;
  }

  function onPos(p) {
    var first = !pos;
    pos = { lat: p.coords.latitude, lng: p.coords.longitude };
    if (!meMarker) {
      meMarker = L.marker([pos.lat, pos.lng], { icon: L.divIcon({ className: '', html: '<div class="mydot"></div>', iconSize: [18, 18], iconAnchor: [9, 9] }), interactive: false }).addTo(map);
    } else {
      meMarker.setLatLng([pos.lat, pos.lng]);
    }
    if (first) { map.setView([pos.lat, pos.lng], 15); }
    var now = Date.now();
    if (job && ['accepted', 'arrived', 'ongoing'].indexOf(job.status) >= 0 && now - lastLocPush > LOC_PUSH_MS) {
      lastLocPush = now;
      PC.db.collection('orders').doc(job.id).update({
        driverLoc: { lat: pos.lat, lng: pos.lng }, updatedAt: PC.FV.serverTimestamp()
      }).catch(function () { /* abaikan */ });
    }
    if (!job && online && now - lastListRender > 8000) { renderPanel(); }
    if (job && first) { drawJobMap(true); }
  }

  // ---------- Order masuk ----------
  function matchesMe(o) {
    return o.vehicle === PC.profile.vehicleType && !skipIds[o.id];
  }

  function pickupDistance(o) {
    return pos ? PC.haversine(pos, o.pickup) : null;
  }

  function startOffers() {
    if (unsubOffers) { return; }
    offersFirst = true;
    unsubOffers = PC.db.collection('orders').where('status', '==', 'searching').onSnapshot(function (qs) {
      var fresh = false;
      offers = {};
      qs.forEach(function (d) { var o = d.data(); o.id = d.id; offers[d.id] = o; });
      if (!offersFirst) {
        qs.docChanges().forEach(function (c) {
          if (c.type === 'added') {
            var o = c.doc.data(); o.id = c.doc.id;
            var dist = pickupDistance(o);
            if (matchesMe(o) && (dist === null || dist <= MAX_PICKUP_M)) { fresh = true; }
          }
        });
      }
      offersFirst = false;
      if (fresh && online && !job) { PC.alertUser(); PC.toast('Ada order baru!'); }
      if (online && !job) { renderPanel(); }
    }, function (e) {
      PC.toast('Gagal memuat order: ' + PC.errText(e));
    });
  }

  function stopOffers() {
    if (unsubOffers) { unsubOffers(); unsubOffers = null; }
    offers = {};
  }

  function goOnline() {
    online = true;
    startGeo();
    startOffers();
    PC.alertUser(); // sekaligus membuka izin audio
    renderPanel();
  }

  function goOffline() {
    online = false;
    stopOffers();
    if (!job) { stopGeo(); }
    renderPanel();
  }

  function acceptOrder(id) {
    if (accepting || job) { return; }
    accepting = true;
    var db = PC.db, FV = PC.FV, p = PC.profile, uid = PC.user.uid;
    var oref = db.collection('orders').doc(id), uref = db.collection('users').doc(uid);
    db.runTransaction(function (tx) {
      return tx.get(oref).then(function (s) {
        if (!s.exists || s.data().status !== 'searching') { throw { code: 'taken' }; }
        tx.update(oref, {
          status: 'accepted', driverId: uid, driverName: p.name, driverPhone: p.phone,
          vehicleName: p.vehicleName, plate: p.plate,
          acceptedAt: FV.serverTimestamp(), updatedAt: FV.serverTimestamp()
        });
        tx.update(uref, { activeJobId: id });
      });
    }).then(function () {
      accepting = false;
      PC.profile.activeJobId = id;
      stopOffers();
      startGeo();
      watchJob(id);
    }).catch(function (e) {
      accepting = false;
      if (e && e.code === 'taken') { PC.toast('Order sudah diambil driver lain.'); }
      else { PC.toast('Gagal mengambil order: ' + PC.errText(e)); }
    });
  }

  // ---------- Order yang sedang dikerjakan ----------
  function clearJobLayers() {
    jobLayers.forEach(function (l) { map.removeLayer(l); });
    jobLayers = [];
    jobMapKey = '';
  }

  function watchJob(id) {
    if (unsubJob) { unsubJob(); unsubJob = null; }
    contact = null;
    unsubJob = PC.db.collection('orders').doc(id).onSnapshot(function (snap) {
      if (!snap.exists) { finishJob(); return; }
      var o = snap.data();
      o.id = id;
      var wasStatus = job ? job.status : null;
      job = o;
      if (!contact && o.driverId === PC.user.uid) { loadContact(id); }
      if (wasStatus !== o.status) { drawJobMap(true); } else { drawJobMap(false); }
      renderPanel();
    }, function (e) {
      PC.toast('Gagal memuat order: ' + PC.errText(e));
    });
  }

  function loadContact(id) {
    PC.db.collection('orders').doc(id).collection('contact').doc('info').get().then(function (s) {
      if (s.exists && job && job.id === id) { contact = s.data(); renderPanel(); }
    }).catch(function () { /* coba lagi pada pembaruan berikutnya */ });
  }

  function targetOf(o) {
    return (o.status === 'ongoing') ? o.dest : o.pickup;
  }

  function drawJobMap(force) {
    if (!job) { return; }
    var key = job.id + ':' + job.status + ':' + (pos ? '1' : '0');
    if (!force && key === jobMapKey) { return; }
    if (key === jobMapKey) { return; }
    jobMapKey = key;
    var o = job;
    var layers = jobLayers;
    jobLayers = [];
    layers.forEach(function (l) { map.removeLayer(l); });
    var tgt = targetOf(o);
    var kind = (o.status === 'ongoing') ? 'dest' : 'pickup';
    jobLayers.push(L.marker([tgt.lat, tgt.lng], { icon: PC.pinIcon(kind) }).addTo(map));
    var from = pos || { lat: o.pickup.lat, lng: o.pickup.lng };
    var to = pos ? tgt : { lat: o.dest.lat, lng: o.dest.lng };
    var myKey = key;
    PC.route(from, to).then(function (r) {
      if (jobMapKey !== myKey) { return; }
      jobLayers.push(L.polyline(r.coords, { color: '#00796b', weight: 5, opacity: 0.85, dashArray: r.approx ? '8 8' : null }).addTo(map));
      var pts = r.coords.concat([[tgt.lat, tgt.lng]]);
      if (pos) { pts.push([pos.lat, pos.lng]); }
      map.fitBounds(L.latLngBounds(pts), {
        paddingTopLeft: [30, 90],
        paddingBottomRight: [30, ($('panel').offsetHeight || 300) + 20],
        maxZoom: 17
      });
    });
  }

  function finishJob() {
    if (unsubJob) { unsubJob(); unsubJob = null; }
    clearJobLayers();
    job = null;
    contact = null;
    PC.profile.activeJobId = null;
    PC.db.collection('users').doc(PC.user.uid).update({ activeJobId: null }).catch(function () { /* abaikan */ });
    if (online) { startOffers(); } else { stopGeo(); }
    renderPanel();
  }

  function advance(next) {
    var id = job.id, db = PC.db, FV = PC.FV;
    var upd = { status: next, updatedAt: FV.serverTimestamp() };
    var batch = db.batch();
    if (next === 'completed') { upd.paid = true; upd.completedAt = FV.serverTimestamp(); }
    batch.update(db.collection('orders').doc(id), upd);
    if (next === 'completed') { batch.update(db.collection('users').doc(PC.user.uid), { activeJobId: null }); }
    batch.commit().then(function () {
      if (next === 'completed') { PC.profile.activeJobId = null; }
    }).catch(function (e) {
      PC.toast('Gagal memperbarui status: ' + PC.errText(e));
    });
  }

  function releaseJob() {
    PC.confirmBox('Lepas order ini?', 'Order dikembalikan agar dicari driver lain. Gunakan hanya bila benar-benar tidak bisa menjemput.', 'Ya, lepas', function () {
      var id = job.id, db = PC.db, FV = PC.FV;
      // berhenti memantau lebih dulu: setelah dilepas, order ini bukan lagi milik driver
      if (unsubJob) { unsubJob(); unsubJob = null; }
      var batch = db.batch();
      batch.update(db.collection('orders').doc(id), {
        status: 'searching', driverId: null, driverName: null, driverPhone: null,
        vehicleName: null, plate: null, acceptedAt: null, driverLoc: null, updatedAt: FV.serverTimestamp()
      });
      batch.update(db.collection('users').doc(PC.user.uid), { activeJobId: null });
      batch.commit().then(function () {
        skipIds[id] = true;
        finishJob();
      }).catch(function (e) {
        PC.toast('Gagal melepas order: ' + PC.errText(e));
        if (job && !unsubJob) { watchJob(job.id); }
      });
    });
  }

  function navUrl(t) {
    return 'https://www.google.com/maps/dir/?api=1&travelmode=driving&destination=' + t.lat + ',' + t.lng;
  }

  // ---------- Tampilan panel ----------
  function renderPanel() {
    lastListRender = Date.now();
    var h = '<div class="grab"></div>';
    var p = $('panel');

    if (!approved) {
      p.innerHTML = h + '<div class="center"><div class="ok">⏳</div><h2>Menunggu persetujuan admin</h2>' +
        '<p class="hint">Akun driver Anda (' + esc(PC.profile.name) + ', ' + esc(PC.profile.phone) + ') sudah terdaftar. ' +
        'Hubungi admin agar akun disetujui. Halaman ini otomatis lanjut setelah disetujui.</p></div>';
      return;
    }

    if (job) { p.innerHTML = h + jobHtml(); return; }

    if (!online) {
      p.innerHTML = h + '<div class="center"><div class="ok">🛌</div><h2>Anda sedang offline</h2>' +
        '<p class="hint">Tekan tombol di bawah untuk mulai menerima order. Biarkan aplikasi tetap terbuka dan layar menyala.</p></div>' +
        '<button class="bigbtn" data-act="online" type="button">Mulai online</button>';
      return;
    }

    var list = Object.keys(offers).map(function (id) { return offers[id]; }).filter(matchesMe);
    list.forEach(function (o) { o._d = pickupDistance(o); });
    list = list.filter(function (o) { return o._d === null || o._d <= MAX_PICKUP_M; });
    list.sort(function (a, b) { return (a._d || 0) - (b._d || 0); });

    h += '<div class="statline"><span class="big">🟢</span><h2>Online</h2></div>';
    if (!pos) { h += '<p class="hint">Mencari lokasi GPS Anda…</p>'; }
    if (!list.length) {
      h += '<div class="placeholder">Belum ada order di sekitar Anda. Tunggu sebentar…</div>';
    } else {
      list.forEach(function (o) {
        var courier = o.mode === 'courier';
        h += '<div class="offer"><div class="top"><span>' + esc(o.icon) + ' ' + esc(o.service) + '</span><span class="p">' + rupiah(o.price) + '</span></div>' +
          '<div class="rt"><b>' + (courier ? 'Ambil' : 'Jemput') + ':</b> ' + esc(o.pickup.label) +
          (o._d !== null ? '<small>' + PC.fmtKm(o._d) + ' dari Anda</small>' : '') +
          '<br><b>' + (courier ? 'Antar' : 'Tujuan') + ':</b> ' + esc(o.dest.label) +
          '<small>' + esc(String(o.km).replace('.', ',')) + ' km · ' + o.minutes + ' mnt' + (courier && o.item ? ' · ' + esc(o.item) : '') + ' · Tunai</small></div>' +
          '<button class="btn primary" data-act="accept" data-id="' + esc(o.id) + '" type="button">Terima order</button></div>';
      });
    }
    h += '<button class="btn ghost" style="width:100%;margin-top:10px" data-act="offline" type="button">Berhenti online</button>';
    p.innerHTML = h;
  }

  function jobHtml() {
    var o = job, courier = o.mode === 'courier';
    var h = '';
    var title, step, tgt = targetOf(o), nextLabel, nextStatus;
    if (o.status === 'accepted') {
      title = courier ? 'Menuju lokasi pengambilan' : 'Menuju lokasi jemput';
      nextLabel = courier ? 'Saya sudah tiba di lokasi ambil' : 'Saya sudah tiba di lokasi jemput';
      nextStatus = 'arrived';
    } else if (o.status === 'arrived') {
      title = courier ? 'Ambil barang' : 'Menunggu penumpang';
      nextLabel = courier ? 'Barang diambil, mulai antar' : 'Penumpang naik, mulai perjalanan';
      nextStatus = 'ongoing';
    } else if (o.status === 'ongoing') {
      title = courier ? 'Antar ke tujuan' : 'Antar ke tujuan';
      nextLabel = 'Selesai – tunai ' + rupiah(o.price) + ' diterima';
      nextStatus = 'completed';
    } else if (o.status === 'completed') {
      return '<div class="center"><div class="ok">✅</div><h2>Order selesai</h2></div>' +
        '<div class="cashbox">Tunai diterima: <b>' + rupiah(o.price) + '</b></div>' +
        '<button class="bigbtn" data-act="jobDone" type="button">OK</button>';
    } else {
      return '<div class="center"><div class="ok">❌</div><h2>Order dibatalkan penumpang</h2></div>' +
        '<button class="bigbtn off" data-act="jobDone" type="button">OK</button>';
    }

    var who = contact ? contact.name : o.passengerName;
    var phone = contact ? contact.phone : '';
    h += '<div class="statline"><span class="big">' + esc(o.icon) + '</span><h2>' + title + '</h2></div>';
    h += '<div class="drv"><div class="av">👤</div><div class="tx"><b>' + esc(who) + '</b><small>' + esc(o.service) + '</small></div>' +
      (phone ? '<a class="callbtn" href="tel:+' + esc(phone) + '" aria-label="Telepon penumpang">📞</a>' : '') + '</div>';
    h += '<div class="kv"><span>' + (courier ? 'Ambil' : 'Jemput') + '</span><span>' + esc(o.pickup.label) + '</span></div>';
    h += '<div class="kv"><span>' + (courier ? 'Antar' : 'Tujuan') + '</span><span>' + esc(o.dest.label) + '</span></div>';
    if (courier) {
      h += '<div class="kv"><span>Barang</span><span>' + esc(o.item || '-') + '</span></div>';
      if (contact) {
        h += '<div class="kv"><span>Penerima</span><span>' + esc(contact.receiver) + ' · <a href="tel:+' + esc(contact.receiverPhone) + '">' + esc(contact.receiverPhone) + '</a></span></div>';
        if (contact.note) { h += '<div class="kv"><span>Catatan</span><span>' + esc(contact.note) + '</span></div>'; }
      }
    }
    h += '<div class="cashbox">Terima tunai dari ' + (courier ? 'pengirim' : 'penumpang') + ': <b>' + rupiah(o.price) + '</b></div>';
    h += '<a class="btn ghost" style="display:block;text-align:center;text-decoration:none;margin-bottom:8px" href="' + navUrl(tgt) + '">🧭 Buka navigasi Google Maps</a>';
    h += '<button class="bigbtn" data-act="advance" data-next="' + nextStatus + '" type="button">' + nextLabel + '</button>';
    if (o.status !== 'ongoing') {
      h += '<button class="btn danger" style="width:100%;margin-top:8px" data-act="release" type="button">Lepas order</button>';
    }
    return h;
  }

  // ---------- Akun dan pendapatan ----------
  function showMenu() {
    var p = PC.profile;
    PC.openOverlay('<h2>Akun driver</h2>' + PC.kv('Nama', esc(p.name)) + PC.kv('Nomor HP', esc(p.phone)) +
      PC.kv('Kendaraan', esc(p.vehicleName) + ' · ' + esc(p.plate)) +
      '<h2 style="margin-top:16px">Pendapatan</h2><div id="earnBox" class="empty">Memuat…</div>' +
      '<div class="btnrow"><button class="btn danger" data-act="logout" type="button">Keluar</button>' +
      '<button class="btn ghost" data-act="close" type="button">Tutup</button></div>');
    PC.db.collection('orders').where('driverId', '==', PC.user.uid).get().then(function (qs) {
      var list = [];
      qs.forEach(function (d) { var o = d.data(); o.id = d.id; if (o.status === 'completed') { list.push(o); } });
      list.sort(function (a, b) { return tms(b.completedAt) - tms(a.completedAt); });
      var start = new Date(); start.setHours(0, 0, 0, 0);
      var todayN = 0, todaySum = 0, allSum = 0;
      list.forEach(function (o) {
        allSum += o.price;
        if (tms(o.completedAt) >= start.getTime()) { todayN++; todaySum += o.price; }
      });
      var box = $('earnBox');
      if (!box) { return; }
      box.className = '';
      var h = '<div class="earn"><div>Hari ini<b>' + rupiah(todaySum) + '</b>' + todayN + ' order</div>' +
        '<div>Total<b>' + rupiah(allSum) + '</b>' + list.length + ' order</div></div>';
      h += list.slice(0, 15).map(function (o) {
        return '<div class="hist"><div class="t"><span>' + esc(o.icon || '') + ' ' + esc(o.service) + '</span><span>' + rupiah(o.price) + '</span></div>' +
          '<small>' + esc(o.pickup.label) + ' → ' + esc(o.dest.label) + '</small>' +
          '<small>' + esc(new Date(tms(o.completedAt)).toLocaleString('id-ID')) + '</small></div>';
      }).join('');
      box.innerHTML = h;
    }).catch(function (e) {
      var box = $('earnBox');
      if (box) { box.textContent = 'Gagal memuat: ' + PC.errText(e); }
    });
  }

  // ---------- Mulai ----------
  function gate(profile) {
    PC.profile = profile;
    var was = approved;
    approved = profile.approved === true;
    if (approved && !started) {
      started = true;
      if (profile.activeJobId) { startGeo(); watchJob(profile.activeJobId); }
    }
    if (approved !== was || !started) { renderPanel(); }
  }

  function init(user, profile) {
    map = PC.makeMap(DEFAULT_CENTER);

    PC.onAct(function (act) {
      if (act === 'close') { PC.closeOverlay(); }
      else if (act === 'logout') { PC.logout(); }
    });

    $('panel').addEventListener('click', function (ev) {
      var t = ev.target.closest('[data-act]');
      if (!t) { return; }
      var act = t.getAttribute('data-act');
      if (act === 'online') { goOnline(); }
      else if (act === 'offline') { goOffline(); }
      else if (act === 'accept') { acceptOrder(t.getAttribute('data-id')); }
      else if (act === 'advance') { advance(t.getAttribute('data-next')); }
      else if (act === 'release') { releaseJob(); }
      else if (act === 'jobDone') { finishJob(); }
    });

    $('btnMenu').addEventListener('click', showMenu);
    $('btnLocate').addEventListener('click', function () {
      if (pos) { map.setView([pos.lat, pos.lng], 16); return; }
      PC.locateOnce().then(function (p) { map.setView([p.lat, p.lng], 16); })
        .catch(function () { PC.toast('Lokasi tidak ditemukan. Aktifkan GPS dan izin lokasi.'); });
    });

    gate(profile);
    // memantau perubahan status persetujuan secara langsung
    PC.db.collection('users').doc(user.uid).onSnapshot(function (snap) {
      if (snap.exists) { gate(snap.data()); }
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    PC.start('driver', init);
  });
})();
