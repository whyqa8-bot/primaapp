(function () {
  'use strict';

  var $ = PC.$, esc = PC.esc, rupiah = PC.rupiah;
  var DEFAULT_CENTER = [-6.1754, 106.8272]; // Jakarta, dipakai bila GPS tidak tersedia

  var state = {
    mode: 'passenger',
    pickup: null,
    dest: null,
    active: 'pickup',
    route: null,
    routing: false,
    selected: { passenger: 'bike', courier: 'send_bike' }
  };

  var map = null;
  var markers = { pickup: null, dest: null };
  var routeLine = null;
  var routeSeq = 0;
  var revSeq = { pickup: 0, dest: 0 };
  var searchTimer = null;

  var unsubOrder = null;
  var trackLayers = [];
  var driverMarker = null;
  var trackFor = null;
  var prevStatus = null;
  var draft = null;
  var submitting = false;

  // ---------- Peta ----------
  function placeMarker(kind) {
    if (markers[kind]) { map.removeLayer(markers[kind]); markers[kind] = null; }
    var p = state[kind];
    if (!p) { return; }
    var m = L.marker([p.lat, p.lng], { draggable: true, icon: PC.pinIcon(kind) }).addTo(map);
    m.on('dragend', function () {
      var ll = m.getLatLng();
      setPoint(kind, { lat: ll.lat, lng: ll.lng }, null, true);
    });
    markers[kind] = m;
  }

  function visibleSheet() { return $('track').classList.contains('hidden') ? $('sheet') : $('track'); }

  function fitPoints(pts) {
    if (pts.length < 2) { return; }
    map.fitBounds(L.latLngBounds(pts), {
      paddingTopLeft: [30, 90],
      paddingBottomRight: [30, (visibleSheet().offsetHeight || 300) + 20],
      maxZoom: 17
    });
  }

  function clearRouteLine() {
    if (routeLine) { map.removeLayer(routeLine); routeLine = null; }
  }

  function drawRoute() {
    clearRouteLine();
    if (!state.route) { return; }
    routeLine = L.polyline(state.route.coords, {
      color: '#1565c0', weight: 5, opacity: 0.85, dashArray: state.route.approx ? '8 8' : null
    }).addTo(map);
    var pts = [[state.pickup.lat, state.pickup.lng], [state.dest.lat, state.dest.lng]].concat(state.route.coords);
    fitPoints(pts);
  }

  // ---------- Titik jemput / tujuan ----------
  function inputOf(kind) { return $(kind === 'pickup' ? 'pickup' : 'dest'); }

  function setPoint(kind, p, label, fromDrag) {
    state[kind] = { lat: p.lat, lng: p.lng, label: label || 'Memuat alamat…' };
    if (!fromDrag) { placeMarker(kind); }
    inputOf(kind).value = state[kind].label;
    if (!label) { reverseLabel(kind); }
    if (kind === 'pickup' && !state.dest) { state.active = 'dest'; }
    onPointsChanged(!fromDrag);
  }

  function reverseLabel(kind) {
    var seq = ++revSeq[kind];
    var p = state[kind];
    PC.reverse(p.lat, p.lng).then(function (label) {
      if (seq !== revSeq[kind] || !state[kind]) { return; }
      state[kind].label = label;
      inputOf(kind).value = label;
    });
  }

  function onPointsChanged(pan) {
    if (state.pickup && state.dest) {
      fetchRoute();
    } else {
      routeSeq++;
      state.route = null;
      state.routing = false;
      clearRouteLine();
      var p = state.pickup || state.dest;
      if (pan && p) { map.setView([p.lat, p.lng], Math.max(map.getZoom(), 15)); }
      renderOptions();
      updateOrderBtn();
    }
  }

  function fetchRoute() {
    var id = ++routeSeq;
    state.routing = true;
    state.route = null;
    clearRouteLine();
    renderOptions();
    updateOrderBtn();
    PC.route(state.pickup, state.dest).then(function (r) {
      if (id !== routeSeq) { return; }
      state.route = r;
      state.routing = false;
      if (r.approx) { PC.toast('Server rute tidak terjangkau, memakai perkiraan jarak.'); }
      drawRoute();
      renderOptions();
      updateOrderBtn();
    });
  }

  // ---------- Pencarian alamat ----------
  function hideSuggestions() { $('sugPickup').innerHTML = ''; $('sugDest').innerHTML = ''; }

  function runSearch(kind, q) {
    var ul = $(kind === 'pickup' ? 'sugPickup' : 'sugDest');
    var c = map.getCenter();
    ul.innerHTML = '<li class="info">Mencari…</li>';
    PC.search(q, { lat: c.lat, lng: c.lng }).then(function (list) {
      if (!list.length) { ul.innerHTML = '<li class="info">Lokasi tidak ditemukan</li>'; return; }
      ul.innerHTML = '';
      list.forEach(function (r) {
        var li = document.createElement('li');
        li.innerHTML = esc(r.title) + '<small>' + esc(r.sub) + '</small>';
        li.addEventListener('mousedown', function (ev) { ev.preventDefault(); });
        li.addEventListener('click', function () {
          ul.innerHTML = '';
          setPoint(kind, { lat: r.lat, lng: r.lng }, r.label);
          map.setView([r.lat, r.lng], 16);
        });
        ul.appendChild(li);
      });
    }).catch(function () {
      ul.innerHTML = '<li class="info">Gagal mencari. Periksa internet atau ketuk peta.</li>';
    });
  }

  function bindSearch(kind) {
    var input = inputOf(kind);
    var ul = $(kind === 'pickup' ? 'sugPickup' : 'sugDest');
    input.addEventListener('focus', function () { state.active = kind; input.select(); });
    input.addEventListener('input', function () {
      clearTimeout(searchTimer);
      var q = input.value.trim();
      if (q.length < 3) { ul.innerHTML = ''; return; }
      searchTimer = setTimeout(function () { runSearch(kind, q); }, 700);
    });
    input.addEventListener('blur', function () { setTimeout(function () { ul.innerHTML = ''; }, 250); });
  }

  // ---------- GPS ----------
  function locate(auto) {
    var btn = $('btnLocate');
    btn.classList.add('busy');
    PC.locateOnce().then(function (p) {
      btn.classList.remove('busy');
      map.setView([p.lat, p.lng], 16);
      if (auto && state.pickup) { return; }
      if (!$('track').classList.contains('hidden')) { return; }
      setPoint('pickup', p, null);
    }).catch(function () {
      btn.classList.remove('busy');
      PC.toast(auto ? 'Aktifkan GPS, atau pilih lokasi jemput lewat pencarian / ketuk peta.'
                    : 'Lokasi tidak ditemukan. Pastikan GPS dan izin lokasi aktif.');
    });
  }

  // ---------- Pilihan layanan ----------
  function currentService() {
    var list = PC.SERVICES[state.mode];
    for (var i = 0; i < list.length; i++) { if (list[i].id === state.selected[state.mode]) { return list[i]; } }
    return list[0];
  }

  function renderOptions() {
    var box = $('options'), sum = $('summary');
    if (state.routing) {
      sum.innerHTML = 'Menghitung rute…';
      box.innerHTML = '<div class="placeholder">Mohon tunggu…</div>';
      return;
    }
    if (!state.route) {
      sum.innerHTML = '';
      box.innerHTML = '<div class="placeholder">Pilih titik ' + (state.mode === 'courier' ? 'ambil dan antar' : 'jemput dan tujuan') + ' untuk melihat tarif.</div>';
      return;
    }
    var km = state.route.distance / 1000;
    sum.innerHTML = '📏 <b>' + PC.fmtKm(state.route.distance) + '</b> · ⏱ <b>' + PC.fmtMin(state.route.duration) + '</b>' + (state.route.approx ? ' · perkiraan' : '');
    box.innerHTML = '';
    PC.SERVICES[state.mode].forEach(function (svc) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'opt' + (svc.id === state.selected[state.mode] ? ' sel' : '');
      b.innerHTML = '<span class="ic">' + svc.icon + '</span>' +
        '<span class="tx"><b>' + esc(svc.name) + '</b><small>' + esc(svc.desc) + '</small></span>' +
        '<span class="pr">' + rupiah(PC.fare(svc, km)) + '<small>est. ' + PC.fmtMin(state.route.duration) + '</small></span>';
      b.addEventListener('click', function () { state.selected[state.mode] = svc.id; renderOptions(); });
      box.appendChild(b);
    });
  }

  function updateOrderBtn() { $('btnOrder').disabled = !(state.route && !state.routing); }

  function setMode(mode) {
    state.mode = mode;
    $('tabPassenger').classList.toggle('active', mode === 'passenger');
    $('tabCourier').classList.toggle('active', mode === 'courier');
    $('courierBox').classList.toggle('hidden', mode !== 'courier');
    $('lblPickup').textContent = mode === 'courier' ? 'Ambil barang di' : 'Jemput di';
    $('lblDest').textContent = mode === 'courier' ? 'Antar ke' : 'Tujuan';
    $('btnOrder').textContent = mode === 'courier' ? 'Kirim sekarang' : 'Pesan sekarang';
    renderOptions();
  }

  // ---------- Membuat pesanan ----------
  function showConfirm() {
    if (!state.route || state.routing) { return; }
    var svc = currentService();
    var d = {
      mode: state.mode, serviceId: svc.id, service: svc.name, icon: svc.icon, vehicle: svc.vehicle,
      pickup: { lat: state.pickup.lat, lng: state.pickup.lng, label: state.pickup.label },
      dest: { lat: state.dest.lat, lng: state.dest.lng, label: state.dest.label },
      km: Math.round(state.route.distance / 100) / 10,
      minutes: Math.max(1, Math.round(state.route.duration / 60)),
      price: PC.fare(svc, state.route.distance / 1000),
      item: null, receiver: '', receiverPhone: '', note: ''
    };
    if (state.mode === 'courier') {
      var name = $('receiverName').value.trim();
      var phone = $('receiverPhone').value.trim();
      if (name.length < 2) { PC.toast('Isi nama penerima.'); $('receiverName').focus(); return; }
      if (!PC.validPhone(phone)) { PC.toast('Nomor HP penerima belum benar.'); $('receiverPhone').focus(); return; }
      d.item = $('itemType').value;
      d.receiver = name;
      d.receiverPhone = PC.normPhone(phone);
      d.note = $('note').value.trim();
    }
    draft = d;

    var courier = d.mode === 'courier';
    var html = '<h2>' + esc(d.icon) + ' Konfirmasi ' + (courier ? 'pengiriman' : 'pesanan') + '</h2>' +
      PC.kv('Layanan', esc(d.service)) +
      PC.kv(courier ? 'Ambil di' : 'Jemput', esc(d.pickup.label)) +
      PC.kv(courier ? 'Antar ke' : 'Tujuan', esc(d.dest.label)) +
      PC.kv('Jarak / waktu', esc(String(d.km).replace('.', ',')) + ' km · ' + d.minutes + ' mnt');
    if (courier) {
      html += PC.kv('Barang', esc(d.item)) + PC.kv('Penerima', esc(d.receiver) + ' (' + esc(d.receiverPhone) + ')');
      if (d.note) { html += PC.kv('Catatan', esc(d.note)); }
    }
    html += PC.kv('Pembayaran', 'Tunai ke driver') + PC.kv('Tarif', '<b>' + rupiah(d.price) + '</b>') +
      '<p class="note">Bayar tunai langsung ke driver setelah ' + (courier ? 'barang diantar' : 'sampai tujuan') + '.</p>' +
      '<div class="btnrow"><button class="btn ghost" data-act="close" type="button">Batal</button>' +
      '<button class="btn primary" data-act="confirm" type="button">' + (courier ? 'Kirim' : 'Pesan') + '</button></div>';
    PC.openOverlay(html);
  }

  function submitOrder() {
    if (!draft || submitting) { return; }
    submitting = true;
    var d = draft, uid = PC.user.uid, db = PC.db, FV = PC.FV;
    var oref = db.collection('orders').doc();
    var batch = db.batch();
    batch.set(oref, {
      passengerId: uid,
      passengerName: PC.firstName(PC.profile.name),
      mode: d.mode, serviceId: d.serviceId, service: d.service, icon: d.icon, vehicle: d.vehicle,
      pickup: d.pickup, dest: d.dest, km: d.km, minutes: d.minutes, price: d.price,
      item: d.item, payment: 'cash', paid: false, status: 'searching',
      driverId: null, driverName: null, driverPhone: null, vehicleName: null, plate: null,
      driverLoc: null, acceptedAt: null,
      createdAt: FV.serverTimestamp(), updatedAt: FV.serverTimestamp()
    });
    batch.set(oref.collection('contact').doc('info'), {
      name: PC.profile.name, phone: PC.profile.phone,
      receiver: d.receiver, receiverPhone: d.receiverPhone, note: d.note
    });
    batch.update(db.collection('users').doc(uid), { activeOrderId: oref.id });
    batch.commit().then(function () {
      submitting = false;
      PC.profile.activeOrderId = oref.id;
      PC.closeOverlay();
      watchOrder(oref.id);
    }).catch(function (e) {
      submitting = false;
      PC.toast('Gagal membuat pesanan: ' + PC.errText(e));
    });
  }

  // ---------- Memantau pesanan ----------
  function clearTrackLayers() {
    trackLayers.forEach(function (l) { map.removeLayer(l); });
    trackLayers = [];
    driverMarker = null;
  }

  function enterTracking() {
    $('sheet').classList.add('hidden');
    $('track').classList.remove('hidden');
    if (markers.pickup) { map.removeLayer(markers.pickup); markers.pickup = null; }
    if (markers.dest) { map.removeLayer(markers.dest); markers.dest = null; }
    clearRouteLine();
  }

  function leaveTracking() {
    if (unsubOrder) { unsubOrder(); unsubOrder = null; }
    clearTrackLayers();
    trackFor = null;
    prevStatus = null;
    $('track').classList.add('hidden');
    $('track').innerHTML = '';
    $('sheet').classList.remove('hidden');
    // siap memesan lagi: tujuan dikosongkan, titik jemput dipertahankan
    state.dest = null;
    state.route = null;
    $('dest').value = '';
    $('receiverName').value = '';
    $('receiverPhone').value = '';
    $('note').value = '';
    state.active = state.pickup ? 'dest' : 'pickup';
    if (state.pickup) { placeMarker('pickup'); } else { locate(true); }
    renderOptions();
    updateOrderBtn();
  }

  function watchOrder(id) {
    if (unsubOrder) { unsubOrder(); unsubOrder = null; }
    enterTracking();
    $('track').innerHTML = '<div class="center"><div class="spinner"></div><p class="hint">Memuat pesanan…</p></div>';
    unsubOrder = PC.db.collection('orders').doc(id).onSnapshot(function (snap) {
      if (!snap.exists) { clearActive(); return; }
      var o = snap.data();
      o.id = id;
      onOrder(o);
    }, function (e) {
      PC.toast('Gagal memuat pesanan: ' + PC.errText(e));
    });
  }

  function drawTrackMap(o) {
    var a = { lat: o.pickup.lat, lng: o.pickup.lng }, b = { lat: o.dest.lat, lng: o.dest.lng };
    if (trackFor !== o.id) {
      trackFor = o.id;
      clearTrackLayers();
      trackLayers.push(L.marker([a.lat, a.lng], { icon: PC.pinIcon('pickup') }).addTo(map));
      trackLayers.push(L.marker([b.lat, b.lng], { icon: PC.pinIcon('dest') }).addTo(map));
      PC.route(a, b).then(function (r) {
        if (trackFor !== o.id) { return; }
        trackLayers.push(L.polyline(r.coords, { color: '#1565c0', weight: 5, opacity: 0.8, dashArray: r.approx ? '8 8' : null }).addTo(map));
        fitPoints(r.coords);
      });
    }
    if (o.driverLoc) {
      var ll = [o.driverLoc.lat, o.driverLoc.lng];
      if (!driverMarker) {
        driverMarker = L.marker(ll, { icon: PC.emojiIcon(o.vehicle === 'mobil' ? '🚗' : '🏍️') }).addTo(map);
        trackLayers.push(driverMarker);
      } else {
        driverMarker.setLatLng(ll);
      }
    }
  }

  function driverCard(o) {
    return '<div class="drv"><div class="av">👤</div><div class="tx"><b>' + esc(o.driverName) + '</b><small>' +
      esc(o.vehicleName) + ' · ' + esc(o.plate) + '</small></div>' +
      '<a class="callbtn" href="tel:+' + esc(o.driverPhone) + '" aria-label="Telepon driver">📞</a></div>';
  }

  function etaText(o, target) {
    if (!o.driverLoc) { return ''; }
    var m = PC.haversine(o.driverLoc, target) * 1.3;
    return ' · sekitar ' + PC.fmtMin(m / 8.3) + ' lagi (' + PC.fmtKm(m) + ')';
  }

  function renderTrack(o) {
    var courier = o.mode === 'courier';
    var h = '';
    var route = '<div class="summary">' + esc(o.icon) + ' <b>' + esc(o.service) + '</b> · ' + esc(String(o.km).replace('.', ',')) + ' km</div>';
    var cancelBtn = '<div class="btnrow"><button class="btn danger" data-act="cancelOrder" type="button">Batalkan pesanan</button></div>';
    var cash = '<div class="cashbox">Bayar tunai ke driver: <b>' + rupiah(o.price) + '</b></div>';

    if (o.status === 'searching') {
      h = '<div class="grab"></div><div class="center"><div class="spinner"></div><h2>Mencari driver…</h2>' +
        '<p class="hint">Mohon tunggu, pesanan Anda sedang ditawarkan ke driver terdekat.</p></div>' + route + cash + cancelBtn;
    } else if (o.status === 'accepted') {
      h = '<div class="grab"></div><div class="statline"><span class="big">🚀</span><h2>Driver menuju ' + (courier ? 'lokasi pengambilan' : 'lokasi jemput') + '</h2></div>' +
        '<p class="hint">Driver sedang di jalan' + etaText(o, o.pickup) + '</p>' + driverCard(o) + route + cash + cancelBtn;
    } else if (o.status === 'arrived') {
      h = '<div class="grab"></div><div class="statline"><span class="big">📍</span><h2>Driver sudah tiba</h2></div>' +
        '<p class="hint">' + (courier ? 'Serahkan barang kepada driver.' : 'Temui driver di titik jemput.') + '</p>' + driverCard(o) + route + cash + cancelBtn;
    } else if (o.status === 'ongoing') {
      h = '<div class="grab"></div><div class="statline"><span class="big">' + (courier ? '📦' : '🛣️') + '</span><h2>' + (courier ? 'Barang sedang diantar' : 'Dalam perjalanan') + '</h2></div>' +
        '<p class="hint">Menuju tujuan' + etaText(o, o.dest) + '</p>' + driverCard(o) + route + cash;
    } else if (o.status === 'completed') {
      h = '<div class="grab"></div><div class="center"><div class="ok">✅</div><h2>' + (courier ? 'Pengiriman selesai' : 'Perjalanan selesai') + '</h2></div>' +
        '<div class="cashbox">Total tunai yang dibayar ke driver: <b>' + rupiah(o.price) + '</b></div>' +
        '<div class="btnrow"><button class="btn primary" data-act="closeOrder" type="button">Selesai</button></div>';
    } else {
      h = '<div class="grab"></div><div class="center"><div class="ok">❌</div><h2>Pesanan dibatalkan</h2></div>' +
        '<div class="btnrow"><button class="btn ghost" data-act="closeOrder" type="button">Tutup</button></div>';
    }
    $('track').innerHTML = h;
  }

  function onOrder(o) {
    if (prevStatus !== null && prevStatus !== o.status && (o.status === 'accepted' || o.status === 'arrived' || o.status === 'completed')) {
      PC.alertUser();
    }
    prevStatus = o.status;
    renderTrack(o);
    drawTrackMap(o);
  }

  function clearActive() {
    PC.db.collection('users').doc(PC.user.uid).update({ activeOrderId: null }).catch(function () { /* abaikan */ });
    PC.profile.activeOrderId = null;
    leaveTracking();
  }

  function cancelOrder() {
    PC.confirmBox('Batalkan pesanan?', 'Pesanan akan dibatalkan dan driver tidak jadi datang.', 'Ya, batalkan', function () {
      PC.db.collection('orders').doc(PC.profile.activeOrderId).update({
        status: 'cancelled', cancelledBy: 'passenger', updatedAt: PC.FV.serverTimestamp()
      }).catch(function () { PC.toast('Pesanan tidak bisa dibatalkan lagi.'); });
    });
  }

  // ---------- Akun dan riwayat ----------
  function statusText(s) {
    if (s === 'completed') { return 'Selesai'; }
    if (s === 'cancelled') { return 'Dibatalkan'; }
    return 'Berjalan';
  }

  function showAccount() {
    PC.openOverlay('<h2>Akun</h2>' + PC.kv('Nama', esc(PC.profile.name)) + PC.kv('Nomor HP', esc(PC.profile.phone)) +
      '<h2 style="margin-top:16px">Riwayat pesanan</h2><div id="histBox" class="empty">Memuat…</div>' +
      '<div class="btnrow"><button class="btn danger" data-act="logout" type="button">Keluar</button>' +
      '<button class="btn ghost" data-act="close" type="button">Tutup</button></div>');
    PC.db.collection('orders').where('passengerId', '==', PC.user.uid).get().then(function (qs) {
      var list = [];
      qs.forEach(function (d) { var o = d.data(); o.id = d.id; list.push(o); });
      list.sort(function (a, b) { return tms(b.createdAt) - tms(a.createdAt); });
      var box = $('histBox');
      if (!box) { return; }
      if (!list.length) { box.innerHTML = 'Belum ada pesanan.'; return; }
      box.className = '';
      box.innerHTML = list.slice(0, 30).map(function (o) {
        return '<div class="hist"><div class="t"><span>' + esc(o.icon || '') + ' ' + esc(o.service) + '</span><span>' + rupiah(o.price) + '</span></div>' +
          '<small>' + esc(o.pickup.label) + ' → ' + esc(o.dest.label) + '</small>' +
          '<small>' + esc(new Date(tms(o.createdAt)).toLocaleString('id-ID')) + ' · ' + statusText(o.status) + '</small></div>';
      }).join('');
    }).catch(function (e) {
      var box = $('histBox');
      if (box) { box.textContent = 'Gagal memuat riwayat: ' + PC.errText(e); }
    });
  }

  function tms(t) { return t && t.toMillis ? t.toMillis() : (t || 0); }

  // ---------- Mulai ----------
  function init() {
    map = PC.makeMap(DEFAULT_CENTER);

    PC.onAct(function (act) {
      if (act === 'close') { PC.closeOverlay(); }
      else if (act === 'confirm') { submitOrder(); }
      else if (act === 'logout') { PC.logout(); }
    });

    $('track').addEventListener('click', function (ev) {
      var t = ev.target.closest('[data-act]');
      if (!t) { return; }
      var act = t.getAttribute('data-act');
      if (act === 'cancelOrder') { cancelOrder(); }
      else if (act === 'closeOrder') { clearActive(); }
    });

    $('tabPassenger').addEventListener('click', function () { setMode('passenger'); });
    $('tabCourier').addEventListener('click', function () { setMode('courier'); });
    $('btnOrder').addEventListener('click', showConfirm);
    $('btnAccount').addEventListener('click', showAccount);
    $('btnLocate').addEventListener('click', function () { locate(false); });
    $('btnGps').addEventListener('click', function () { locate(false); });
    bindSearch('pickup');
    bindSearch('dest');

    map.on('click', function (e) {
      if (!$('track').classList.contains('hidden')) { return; }
      hideSuggestions();
      if (document.activeElement && document.activeElement.blur) { document.activeElement.blur(); }
      var kind = state.active === 'dest' ? 'dest' : 'pickup';
      setPoint(kind, { lat: e.latlng.lat, lng: e.latlng.lng }, null);
    });

    setMode('passenger');
    updateOrderBtn();

    if (PC.profile.activeOrderId) {
      watchOrder(PC.profile.activeOrderId);
    }
    locate(true);
  }

  document.addEventListener('DOMContentLoaded', function () {
    PC.start('passenger', init);
  });
})();
