# Prima Carts - Penumpang, Kurir, dan Driver (Android)

Proyek ini menghasilkan **dua aplikasi Android** dari satu repository:

- **Prima Carts** (penumpang dan kurir): pilih jemput/tujuan di peta
  OpenStreetMap, lihat rute dan tarif, pesan, lacak driver, bayar **tunai**.
- **Prima Driver**: daftar, (disetujui admin), mulai online, terima order,
  navigasi, ubah status, dan tandai **tunai diterima**. Ada ringkasan pendapatan.

Tampilan berupa web app di dalam aplikasi (`app/src/main/assets/web/`),
dibungkus WebView dengan bar navigasi bawah. Server memakai Firebase.

## Langkah awal (wajib, sekali saja)

Ikuti **PANDUAN_FIREBASE.md** (sekitar 15 menit): buat proyek Firebase,
aktifkan login, buat database, tempel `firebase/firestore.rules`, lalu isi
`app/src/main/assets/web/firebase-config.js`.

## Build APK otomatis

1. Upload seluruh isi folder ini ke repository GitHub (branch `main`).
   Pastikan folder `.github/workflows/` (pakai titik) ikut ter-upload.
2. Tab **Actions** > workflow **Build Android APK** berjalan otomatis
   (atau klik **Run workflow**).
3. Setelah hijau, unduh artifact **PrimaCarts-APK**:
   `PrimaCarts-Penumpang.apk` dan `PrimaCarts-Driver.apk`.

## Mengubah isi

- Tarif dan jenis layanan: `app/src/main/assets/web/common.js` (`SERVICES`)
- Tampilan penumpang: `index.html`, `passenger.js`
- Tampilan driver: `driver.html`, `driver.js`
- Nama aplikasi dan package: `app/build.gradle` (bagian `productFlavors`)

## Catatan

- APK release ditandatangani dengan kunci debug supaya langsung bisa
  di-install. Untuk Google Play Store, gunakan keystore sendiri.
- Server peta, cari alamat, dan rute gratis (OpenStreetMap, Nominatim, OSRM)
  hanya untuk skala kecil.
