# Panduan Setup Server (Firebase) - sekali saja, sekitar 15 menit

Aplikasi penumpang dan driver memakai Firebase (milik Google) sebagai server:
login, daftar pesanan, dan pelacakan driver real-time. Paket gratis (Spark)
cukup untuk uji coba dan layanan kecil.

Yang dibutuhkan: akun Google.

## 1. Buat proyek
1. Buka https://console.firebase.google.com lalu klik **Create a project**.
2. Nama bebas (misal `primacarts`). Google Analytics boleh dimatikan.

## 2. Aktifkan login
1. Menu kiri: **Build > Authentication > Get started**.
2. Tab **Sign-in method** > pilih **Email/Password** > aktifkan (Enable) > Save.
   (Aplikasi memakai nomor HP + kata sandi; nomor HP diubah otomatis
   menjadi alamat email internal, jadi tidak ada SMS dan tidak ada biaya.)

## 3. Buat database
1. Menu kiri: **Build > Firestore Database > Create database**.
2. Lokasi: **asia-southeast2 (Jakarta)**.
3. Pilih **Production mode** > Create.

## 4. Pasang aturan keamanan
1. Di Firestore, buka tab **Rules**.
2. Hapus semua isinya, lalu tempel seluruh isi file `firebase/firestore.rules`
   dari proyek ini.
3. Klik **Publish**.

Tanpa langkah ini aplikasi akan menampilkan "permission denied".

## 5. Hubungkan aplikasi
1. Klik ikon roda gigi (Project settings) > tab **General**.
2. Gulir ke **Your apps** > klik ikon web `</>` > beri nama bebas > Register app.
3. Akan muncul kode `firebaseConfig = { ... }`. Salin nilai-nilainya.
4. Di GitHub repo Anda, buka file
   `app/src/main/assets/web/firebase-config.js`, klik ikon pensil, dan ganti
   semua tulisan `ISI_...` dengan nilai tadi. Commit.
5. Build otomatis berjalan di tab Actions. Unduh dua APK dari Artifacts:
   - `PrimaCarts-Penumpang.apk`
   - `PrimaCarts-Driver.apk`

## 6. Menyetujui driver
Driver yang mendaftar belum bisa menerima order sebelum Anda setujui:
1. Firebase Console > Firestore Database > Data > koleksi **users**.
2. Buka dokumen driver (lihat kolom `name` dan `phone`).
3. Ubah field `approved` dari `false` menjadi `true`.
Aplikasi driver otomatis lanjut dalam beberapa detik.

Sebelum menyetujui, periksa data driver sungguhan (KTP, SIM, STNK,
foto kendaraan) di luar aplikasi.

## 7. Uji coba
1. HP A: pasang APK Penumpang, daftar dengan nomor HP dan kata sandi.
2. HP B: pasang APK Driver, daftar, lalu Anda setujui (langkah 6).
3. HP B: tekan **Mulai online**. HP A: pilih jemput/tujuan, **Pesan**.
4. HP B menerima order, lanjutkan status sampai **Selesai - tunai diterima**.

## Batasan versi ini
- Pembayaran hanya **tunai** (driver menandai uang sudah diterima).
- Lokasi driver hanya terkirim saat aplikasi driver terbuka dan layar menyala.
- Belum ada notifikasi saat aplikasi ditutup (driver harus membuka aplikasi
  dalam keadaan online; ada bunyi dan getar untuk order baru).
- Tarif dihitung di aplikasi (ubah di `common.js`, bagian `SERVICES`).
- Server peta, cari alamat, dan rute gratis hanya untuk skala kecil.
- Cocok untuk uji coba dan layanan komunitas kecil. Untuk operasi komersial,
  periksa izin usaha/angkutan, asuransi, dan keselamatan penumpang.
